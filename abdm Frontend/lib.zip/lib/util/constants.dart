import 'package:flutter/material.dart';

class AppColor {
  static const Color primaryColor = Color(0xFF1E88E5);
  static const Color primaryDark = Color(0xFF1565C0);
  static const Color accentColor = Color(0xFF00ACC1);
  static const Color backgroundColor = Color(0xFFF4F6F9);
  static const Color cardColor = Colors.white;
  static const Color textPrimary = Color(0xFF212121);
  static const Color textSecondary = Color(0xFF757575);
  static const Color border = Color(0xFFE0E0E0);

  // Status colors
  static const Color green = Color(0xFF4CAF50);
  static const Color orange = Color(0xFFFF9800);
  static const Color red = Color(0xFFF44336);
  static const Color blue = Color(0xFF2196F3);
}

class AppImages {
  static const String appLogo = 'assets/images/abdm_logo.png';
  static const String abhaCardBg = 'assets/images/abha_card_bg.png';
  static const String qrPlaceholder = 'assets/images/qr_placeholder.png';
}
