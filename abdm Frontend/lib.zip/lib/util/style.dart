import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'constants.dart';

class Dimensions {
  static double fontSizeSmall = 12;
  static double fontSizeDefault = 14;
  static double fontSizeLarge = 16;
  static double fontSizeExtraLarge = 18;
  static double fontSizeOverLarge = 24;
}

final fontRegular = GoogleFonts.inter(
  fontWeight: FontWeight.w400,
  fontSize: Dimensions.fontSizeDefault.sp,
  color: AppColor.textPrimary,
);

final fontMedium = GoogleFonts.inter(
  fontWeight: FontWeight.w500,
  fontSize: Dimensions.fontSizeLarge.sp,
  color: AppColor.textPrimary,
);

final fontBold = GoogleFonts.inter(
  fontWeight: FontWeight.w700,
  fontSize: Dimensions.fontSizeExtraLarge.sp,
  color: AppColor.textPrimary,
);

final fontSmall = GoogleFonts.inter(
  fontWeight: FontWeight.w400,
  fontSize: Dimensions.fontSizeSmall.sp,
  color: AppColor.textSecondary,
);

final fontTitle = GoogleFonts.inter(
  fontWeight: FontWeight.w700,
  fontSize: Dimensions.fontSizeOverLarge.sp,
  color: AppColor.primaryDark,
);
