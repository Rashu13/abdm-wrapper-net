class ApiEndpoints {
  static String baseUrl = "https://sbx.wati.digital";

  // M1: ABHA Creation & Authentication Endpoints
  static String generateAadhaarOtp = "$baseUrl/api/v1/m1/aadhaar/generate-otp";
  static String verifyAadhaarOtp = "$baseUrl/api/v1/m1/aadhaar/verify-otp";
  static String createAbhaAddress = "$baseUrl/api/v1/m1/abha/create-address";
  static String getAbhaProfile = "$baseUrl/api/v1/m1/abha/profile";
  static String downloadAbhaCard = "$baseUrl/api/v1/m1/abha/card/download";

  // M2: HIP (Health Information Provider) Endpoints
  static String discoverPatient = "$baseUrl/api/v1/m2/hip/patient/discover";
  static String linkCareContext = "$baseUrl/api/v1/m2/hip/care-context/link";
  static String getLinkedContexts = "$baseUrl/api/v1/m2/hip/care-context/list";
  static String notifyConsent = "$baseUrl/api/v1/m2/hip/consent/notify";

  // M3: HIU (Health Information User) Endpoints
  static String createConsentRequest = "$baseUrl/api/v1/m3/hiu/consent/request";
  static String fetchConsentStatus = "$baseUrl/api/v1/m3/hiu/consent/status";
  static String fetchEncryptedHealthRecord = "$baseUrl/api/v1/m3/hiu/health-information/fetch";
}
