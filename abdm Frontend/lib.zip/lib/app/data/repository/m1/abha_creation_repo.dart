import 'dart:convert';
import '../../../api/abdm_server.dart';
import '../../model/response/m1/abha_profile_model.dart';
import '../../../../util/api_endpoints.dart';

class AbhaCreationRepo {
  static Future<String?> generateAadhaarOtp(String aadhaarNumber) async {
    final response = await AbdmServer.postRequest(
      endpoint: ApiEndpoints.generateAadhaarOtp,
      body: {'aadhaar': aadhaarNumber},
    );
    if (response != null && response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return data['txnId'] ?? 'TXN_TEMP_12345';
    }
    return 'TXN_TEMP_12345'; // Fallback txnId for mock
  }

  static Future<AbhaProfileModel?> verifyAadhaarOtp(String otp, String txnId) async {
    final response = await AbdmServer.postRequest(
      endpoint: ApiEndpoints.verifyAadhaarOtp,
      body: {'otp': otp, 'txnId': txnId},
    );
    if (response != null && response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return AbhaProfileModel.fromJson(data['profile'] ?? data);
    }
    return AbhaProfileModel.fromJson({}); // Fallback model for demo
  }
}
