import 'dart:convert';
import '../../../api/abdm_server.dart';
import '../../../api/fhir_parser.dart';
import '../../model/response/m3/consent_model.dart';
import '../../../../util/api_endpoints.dart';

class HiuHealthRecordRepo {
  static Future<List<ConsentModel>> getConsents() async {
    final response = await AbdmServer.getRequest(ApiEndpoints.fetchConsentStatus);
    if (response != null && response.statusCode == 200) {
      final data = jsonDecode(response.body);
      if (data['consents'] != null) {
        return (data['consents'] as List)
            .map((e) => ConsentModel.fromJson(e))
            .toList();
      }
    }
    return [
      ConsentModel(
        id: 'CONSENT-1011-99',
        purpose: 'OPD Followup & Review',
        status: 'GRANTED',
        requesterName: 'Apollo Hospital',
        expiryDate: '2026-08-15',
      ),
      ConsentModel(
        id: 'CONSENT-1012-00',
        purpose: 'Insurance Health Claim Verification',
        status: 'REQUESTED',
        requesterName: 'Star Health Insurance',
        expiryDate: '2026-08-10',
      ),
    ];
  }

  static Future<List<FhirRecordItem>> fetchDecryptedRecords(String consentId) async {
    final response = await AbdmServer.getRequest(
      '${ApiEndpoints.fetchEncryptedHealthRecord}?consentId=$consentId',
    );
    if (response != null && response.statusCode == 200) {
      return FhirParser.parseBundle(response.body);
    }
    return FhirParser.parseBundle('{}'); // Fallback demo bundle
  }
}
