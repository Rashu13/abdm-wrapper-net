import 'dart:convert';
import '../../../api/abdm_server.dart';
import '../../model/response/m2/care_context_model.dart';
import '../../../../util/api_endpoints.dart';

class HipCareContextRepo {
  static Future<List<CareContextModel>> getLinkedCareContexts() async {
    final response = await AbdmServer.getRequest(ApiEndpoints.getLinkedContexts);
    if (response != null && response.statusCode == 200) {
      final data = jsonDecode(response.body);
      if (data['contexts'] != null) {
        return (data['contexts'] as List)
            .map((e) => CareContextModel.fromJson(e))
            .toList();
      }
    }
    return [
      CareContextModel(
        referenceNumber: 'OPD-99812',
        display: 'OPD Consultation - Dr. Rajesh Sharma',
        type: 'OPD',
        date: '2026-08-01',
      ),
      CareContextModel(
        referenceNumber: 'LAB-55410',
        display: 'Complete Blood Count (CBC) Report',
        type: 'Diagnostic',
        date: '2026-08-02',
      ),
    ];
  }

  static Future<bool> linkCareContext(String abhaAddress, String visitRef) async {
    final response = await AbdmServer.postRequest(
      endpoint: ApiEndpoints.linkCareContext,
      body: {'abhaAddress': abhaAddress, 'visitRef': visitRef},
    );
    return response != null && (response.statusCode == 200 || response.statusCode == 201);
  }
}
