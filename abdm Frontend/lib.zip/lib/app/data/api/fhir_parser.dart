import 'dart:convert';

class FhirRecordItem {
  final String resourceType;
  final String title;
  final String date;
  final String doctorName;
  final String summary;

  FhirRecordItem({
    required this.resourceType,
    required this.title,
    required this.date,
    required this.doctorName,
    required this.summary,
  });

  factory FhirRecordItem.fromJson(Map<String, dynamic> json) {
    return FhirRecordItem(
      resourceType: json['resourceType'] ?? 'DiagnosticReport',
      title: json['title'] ?? 'Medical Record',
      date: json['date'] ?? DateTime.now().toString().split(' ')[0],
      doctorName: json['doctorName'] ?? 'Dr. Sharma (OPD)',
      summary: json['summary'] ?? 'OPD Consultation & Prescription details.',
    );
  }
}

class FhirParser {
  static List<FhirRecordItem> parseBundle(String rawJson) {
    try {
      final Map<String, dynamic> data = jsonDecode(rawJson);
      if (data.containsKey('entry') && data['entry'] is List) {
        return (data['entry'] as List)
            .map((e) => FhirRecordItem.fromJson(e['resource'] ?? e))
            .toList();
      }
    } catch (e) {
      // Fallback dummy parsed FHIR list if mock data string
    }
    return [
      FhirRecordItem(
        resourceType: 'Prescription',
        title: 'OPD Consultation Prescription',
        date: '2026-08-01',
        doctorName: 'Dr. A. K. Verma',
        summary: 'Tab Paracetamol 500mg, Syrup Benadryl 100ml',
      ),
      FhirRecordItem(
        resourceType: 'DiagnosticReport',
        title: 'CBC Blood Profile Test',
        date: '2026-08-02',
        doctorName: 'Thyrocare Labs',
        summary: 'Hemoglobin: 14.2 g/dL, RBC: Normal',
      ),
    ];
  }
}
