class AbhaProfileModel {
  final String? abhaNumber;
  final String? abhaAddress;
  final String? name;
  final String? gender;
  final String? dob;
  final String? mobile;
  final String? profilePhoto;

  AbhaProfileModel({
    this.abhaNumber,
    this.abhaAddress,
    this.name,
    this.gender,
    this.dob,
    this.mobile,
    this.profilePhoto,
  });

  factory AbhaProfileModel.fromJson(Map<String, dynamic> json) {
    return AbhaProfileModel(
      abhaNumber: json['abhaNumber'] ?? '91-8842-1092-3312',
      abhaAddress: json['abhaAddress'] ?? 'user@abdm',
      name: json['name'] ?? 'Rahul Sharma',
      gender: json['gender'] ?? 'M',
      dob: json['dob'] ?? '15/08/1995',
      mobile: json['mobile'] ?? '9876543210',
      profilePhoto: json['profilePhoto'],
    );
  }
}
