import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/dashboard_controller.dart';
import '../../m1_abha/views/create_abha_view.dart';
import '../../m2_hip/views/discovery_view.dart';
import '../../m3_hiu/views/consent_request_view.dart';
import '../../../../util/constants.dart';

class DashboardView extends GetView<DashboardController> {
  DashboardView({Key? key}) : super(key: key);

  final List<Widget> _pages = [
    CreateAbhaView(),
    const DiscoveryView(),
    const ConsentRequestView(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Obx(() => _pages[controller.currentIndex.value]),
      bottomNavigationBar: Obx(
        () => BottomNavigationBar(
          currentIndex: controller.currentIndex.value,
          onTap: controller.changeTab,
          selectedItemColor: AppColor.primaryColor,
          unselectedItemColor: AppColor.textSecondary,
          items: const [
            BottomNavigationBarViewItem(
              icon: Icon(Icons.badge),
              label: 'M1: ABHA',
            ),
            BottomNavigationBarViewItem(
              icon: Icon(Icons.local_hospital),
              label: 'M2: HIP',
            ),
            BottomNavigationBarViewItem(
              icon: Icon(Icons.folder_shared),
              label: 'M3: HIU',
            ),
          ],
        ),
      ),
    );
  }
}

class BottomNavigationBarViewItem extends BottomNavigationBarItem {
  const BottomNavigationBarViewItem({required Widget icon, required String label})
      : super(icon: icon, label: label);
}
