import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/care_context_controller.dart';
import '../../../../util/constants.dart';
import '../../../../util/style.dart';

class DiscoveryView extends GetView<CareContextController> {
  const DiscoveryView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('HIP Care Contexts (M2)'),
        backgroundColor: AppColor.primaryColor,
      ),
      body: Obx(() {
        if (controller.isLoading.value) {
          return const Center(child: CircularProgressIndicator());
        }
        return ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: controller.careContexts.length,
          itemBuilder: (context, index) {
            final item = controller.careContexts[index];
            return Card(
              margin: const EdgeInsets.only(bottom: 12),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              child: ListTile(
                leading: CircleAvatar(
                  backgroundColor: AppColor.primaryColor.withOpacity(0.1),
                  child: const Icon(Icons.local_hospital, color: AppColor.primaryColor),
                ),
                title: Text(item.display, style: fontBold),
                subtitle: Text('Ref: ${item.referenceNumber} | Date: ${item.date}', style: fontSmall),
                trailing: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: AppColor.blue.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(item.type, style: fontSmall.copyWith(color: AppColor.blue, fontWeight: FontWeight.bold)),
                ),
              ),
            );
          },
        );
      }),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: AppColor.primaryColor,
        onPressed: () {
          controller.linkNewCareContext('rahul@abdm', 'OPD-VISIT-${DateTime.now().millisecondsSinceEpoch % 10000}');
        },
        icon: const Icon(Icons.add_link, color: Colors.white),
        label: Text('Link Care Context', style: fontMedium.copyWith(color: Colors.white)),
      ),
    );
  }
}
