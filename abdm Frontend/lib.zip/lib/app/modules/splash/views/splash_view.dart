import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/splash_controller.dart';
import '../../../../util/constants.dart';
import '../../../../util/style.dart';

class SplashView extends GetView<SplashController> {
  const SplashView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.primaryDark,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.health_and_safety_rounded, size: 90, color: Colors.white),
            const SizedBox(height: 20),
            Text(
              "ABDM Healthcare",
              style: fontTitle.copyWith(color: Colors.white),
            ),
            const SizedBox(height: 8),
            Text(
              "Ayushman Bharat Digital Mission (M1, M2, M3)",
              style: fontSmall.copyWith(color: Colors.white70),
            ),
            const SizedBox(height: 40),
            const CircularProgressIndicator(color: Colors.white),
          ],
        ),
      ),
    );
  }
}
