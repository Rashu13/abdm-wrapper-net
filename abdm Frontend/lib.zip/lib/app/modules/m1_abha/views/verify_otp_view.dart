import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/abha_creation_controller.dart';
import '../../../../util/constants.dart';
import '../../../../util/style.dart';

class VerifyOtpView extends GetView<AbhaCreationController> {
  VerifyOtpView({Key? key}) : super(key: key);

  final TextEditingController _otpController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Verify OTP (M1)'),
        backgroundColor: AppColor.primaryColor,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Step 2: Enter Aadhaar OTP', style: fontBold),
            const SizedBox(height: 8),
            Text(
              'Enter the 6-digit OTP received on your mobile.',
              style: fontSmall,
            ),
            const SizedBox(height: 24),
            TextField(
              controller: _otpController,
              keyboardType: TextInputType.number,
              maxLength: 6,
              decoration: const InputDecoration(
                labelText: 'OTP',
                hintText: '6-digit OTP',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.security),
              ),
            ),
            const SizedBox(height: 30),
            Obx(() => SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColor.primaryColor,
                    ),
                    onPressed: controller.isLoading.value
                        ? null
                        : () => controller.verifyOtp(_otpController.text),
                    child: controller.isLoading.value
                        ? const CircularProgressIndicator(color: Colors.white)
                        : Text('Verify & Create ABHA', style: fontMedium.copyWith(color: Colors.white)),
                  ),
                )),
          ],
        ),
      ),
    );
  }
}
