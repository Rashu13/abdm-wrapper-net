import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:qr_flutter/qr_flutter.dart';
import '../controllers/abha_creation_controller.dart';
import '../../../../util/constants.dart';
import '../../../../util/style.dart';

class AbhaCardView extends GetView<AbhaCreationController> {
  const AbhaCardView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('ABHA Card (M1)'),
        backgroundColor: AppColor.primaryColor,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
        child: Obx(() {
          final profile = controller.abhaProfile.value;
          String abhaNum = profile?.abhaNumber ?? '91-8842-1092-3312';
          String abhaAddr = profile?.abhaAddress ?? 'rahul@abdm';
          String name = profile?.name ?? 'Rahul Sharma';
          String gender = profile?.gender ?? 'M';
          String dob = profile?.dob ?? '15/08/1995';

          return Column(
            children: [
              Card(
                elevation: 6,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                color: Colors.white,
                child: Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              const Icon(Icons.health_and_safety, color: AppColor.primaryColor, size: 30),
                              const SizedBox(width: 8),
                              Text('ABHA Card', style: fontBold.copyWith(color: AppColor.primaryDark)),
                            ],
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(
                              color: AppColor.green.withOpacity(0.15),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Text('VERIFIED', style: fontSmall.copyWith(color: AppColor.green, fontWeight: FontWeight.bold)),
                          ),
                        ],
                      ),
                      const Divider(height: 30),
                      Row(
                        children: [
                          QrImageView(
                            data: '$abhaNum | $abhaAddr',
                            version: QrVersions.auto,
                            size: 100.0,
                          ),
                          const SizedBox(width: 16),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(name, style: fontBold),
                                const SizedBox(height: 4),
                                Text('ABHA Number:', style: fontSmall),
                                Text(abhaNum, style: fontMedium.copyWith(color: AppColor.primaryColor)),
                                const SizedBox(height: 4),
                                Text('ABHA Address:', style: fontSmall),
                                Text(abhaAddr, style: fontMedium),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('Gender: $gender', style: fontSmall),
                          Text('DOB: $dob', style: fontSmall),
                        ],
                      )
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 30),
              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(backgroundColor: AppColor.primaryDark),
                  onPressed: () {
                    Get.snackbar('Download Started', 'Downloading ABHA Card PDF...');
                  },
                  icon: const Icon(Icons.download, color: Colors.white),
                  label: Text('Download ABHA Card PDF', style: fontMedium.copyWith(color: Colors.white)),
                ),
              )
            ],
          );
        }),
      ),
    );
  }
}
