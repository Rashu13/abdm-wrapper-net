import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/abha_creation_controller.dart';
import '../../../../util/constants.dart';
import '../../../../util/style.dart';

class CreateAbhaView extends GetView<AbhaCreationController> {
  CreateAbhaView({Key? key}) : super(key: key);

  final TextEditingController _aadhaarController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Create ABHA (M1)'),
        backgroundColor: AppColor.primaryColor,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Step 1: Enter Aadhaar Number', style: fontBold),
            const SizedBox(height: 8),
            Text(
              'An OTP will be sent to your Aadhaar-registered mobile number.',
              style: fontSmall,
            ),
            const SizedBox(height: 24),
            TextField(
              controller: _aadhaarController,
              keyboardType: TextInputType.number,
              maxLength: 12,
              decoration: const InputDecoration(
                labelText: 'Aadhaar Number',
                hintText: '12-digit Aadhaar Number',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.fingerprint),
              ),
            ),
            const SizedBox(height: 30),
            Obx(() => SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColor.primaryColor,
                    ),
                    onPressed: controller.isLoading.value
                        ? null
                        : () => controller.sendAadhaarOtp(_aadhaarController.text),
                    child: controller.isLoading.value
                        ? const CircularProgressIndicator(color: Colors.white)
                        : Text('Get Aadhaar OTP', style: fontMedium.copyWith(color: Colors.white)),
                  ),
                )),
          ],
        ),
      ),
    );
  }
}
