import 'package:get/get.dart';
import '../../../data/model/response/m1/abha_profile_model.dart';
import '../../../data/repository/m1/abha_creation_repo.dart';
import '../../../routes/app_paths.dart';

class AbhaCreationController extends GetxController {
  var isLoading = false.obs;
  var aadhaarNumber = ''.obs;
  var otp = ''.obs;
  var txnId = ''.obs;
  var abhaProfile = Rxn<AbhaProfileModel>();

  Future<void> sendAadhaarOtp(String inputAadhaar) async {
    if (inputAadhaar.length < 12) {
      Get.snackbar('Invalid Input', 'Please enter a valid 12-digit Aadhaar number.');
      return;
    }
    aadhaarNumber.value = inputAadhaar;
    isLoading.value = true;
    var resultTxn = await AbhaCreationRepo.generateAadhaarOtp(inputAadhaar);
    isLoading.value = false;
    if (resultTxn != null) {
      txnId.value = resultTxn;
      Get.toNamed(Routes.M1_VERIFY_OTP);
    }
  }

  Future<void> verifyOtp(String inputOtp) async {
    if (inputOtp.length < 6) {
      Get.snackbar('Invalid OTP', 'Please enter 6-digit OTP.');
      return;
    }
    otp.value = inputOtp;
    isLoading.value = true;
    var profile = await AbhaCreationRepo.verifyAadhaarOtp(inputOtp, txnId.value);
    isLoading.value = false;
    if (profile != null) {
      abhaProfile.value = profile;
      Get.offNamed(Routes.M1_ABHA_CARD);
    }
  }
}
