import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/health_record_controller.dart';
import '../../../../util/constants.dart';
import '../../../../util/style.dart';

class HealthRecordViewerPage extends GetView<HealthRecordController> {
  const HealthRecordViewerPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('FHIR Health Records (M3)'),
        backgroundColor: AppColor.primaryColor,
      ),
      body: Obx(() {
        if (controller.isFetchingRecords.value) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const CircularProgressIndicator(),
                const SizedBox(height: 16),
                Text('Decrypting FHIR Data (ECDH)...', style: fontMedium),
              ],
            ),
          );
        }

        return ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: controller.fhirRecords.length,
          itemBuilder: (context, index) {
            final record = controller.fhirRecords[index];
            return Card(
              margin: const EdgeInsets.only(bottom: 12),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              child: ExpansionTile(
                leading: CircleAvatar(
                  backgroundColor: AppColor.accentColor.withOpacity(0.15),
                  child: const Icon(Icons.receipt_long, color: AppColor.accentColor),
                ),
                title: Text(record.title, style: fontBold),
                subtitle: Text('Doctor/Provider: ${record.doctorName} | Date: ${record.date}', style: fontSmall),
                children: [
                  Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: AppColor.backgroundColor,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('FHIR Resource: ${record.resourceType}', style: fontSmall.copyWith(fontWeight: FontWeight.bold)),
                          const SizedBox(height: 6),
                          Text(record.summary, style: fontRegular),
                        ],
                      ),
                    ),
                  )
                ],
              ),
            );
          },
        );
      }),
    );
  }
}
