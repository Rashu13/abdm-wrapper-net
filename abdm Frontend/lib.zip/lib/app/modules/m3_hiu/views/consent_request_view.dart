import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/health_record_controller.dart';
import '../../../../routes/app_paths.dart';
import '../../../../util/constants.dart';
import '../../../../util/style.dart';

class ConsentRequestView extends GetView<HealthRecordController> {
  const ConsentRequestView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('HIU Consents (M3)'),
        backgroundColor: AppColor.primaryColor,
      ),
      body: Obx(() {
        if (controller.isLoadingConsents.value) {
          return const Center(child: CircularProgressIndicator());
        }
        return ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: controller.consents.length,
          itemBuilder: (context, index) {
            final consent = controller.consents[index];
            bool isGranted = consent.status == 'GRANTED';

            return Card(
              margin: const EdgeInsets.only(bottom: 12),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(consent.requesterName, style: fontBold),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(
                            color: (isGranted ? AppColor.green : AppColor.orange).withOpacity(0.15),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Text(
                            consent.status,
                            style: fontSmall.copyWith(
                              color: isGranted ? AppColor.green : AppColor.orange,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Text('Purpose: ${consent.purpose}', style: fontRegular),
                    Text('Expires: ${consent.expiryDate}', style: fontSmall),
                    const SizedBox(height: 12),
                    if (isGranted)
                      Align(
                        alignment: Alignment.centerRight,
                        child: ElevatedButton.icon(
                          style: ElevatedButton.styleFrom(backgroundColor: AppColor.primaryColor),
                          onPressed: () {
                            controller.fetchAndDecryptRecords(consent.id);
                            Get.toNamed(Routes.M3_HEALTH_RECORDS);
                          },
                          icon: const Icon(Icons.folder_open, color: Colors.white, size: 18),
                          label: Text('View Health Records', style: fontMedium.copyWith(color: Colors.white)),
                        ),
                      ),
                  ],
                ),
              ),
            );
          },
        );
      }),
    );
  }
}
