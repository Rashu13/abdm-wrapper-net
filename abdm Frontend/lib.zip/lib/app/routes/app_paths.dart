abstract class Routes {
  static const SPLASH = '/splash';
  static const DASHBOARD = '/dashboard';

  // Milestone M1 Routes
  static const M1_CREATE_ABHA = '/m1/create-abha';
  static const M1_VERIFY_OTP = '/m1/verify-otp';
  static const M1_ABHA_CARD = '/m1/abha-card';

  // Milestone M2 Routes
  static const M2_DISCOVERY = '/m2/discovery';
  static const M2_LINK_CARE_CONTEXT = '/m2/link-care-context';

  // Milestone M3 Routes
  static const M3_CONSENT_REQUEST = '/m3/consent-request';
  static const M3_HEALTH_RECORDS = '/m3/health-records';
}
