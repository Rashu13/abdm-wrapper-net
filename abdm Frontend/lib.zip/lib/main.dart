import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'app/routes/app_pages.dart';
import 'app/routes/app_paths.dart';
import 'app/modules/splash/bindings/splash_binding.dart';
import 'util/constants.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await GetStorage.init();

  runApp(
    ScreenUtilInit(
      designSize: const Size(360, 800),
      minTextAdapt: true,
      splitScreenMode: true,
      builder: (context, child) {
        return GetMaterialApp(
          debugShowCheckedModeBanner: false,
          title: "ABDM Healthcare App",
          theme: ThemeData(
            primaryColor: AppColor.primaryColor,
            scaffoldBackgroundColor: AppColor.backgroundColor,
            useMaterial3: false,
          ),
          initialRoute: AppPages.INITIAL,
          getPages: AppPages.routes,
          initialBinding: SplashBinding(),
        );
      },
    ),
  );
}
